package com.editor;

import org.apache.wicket.PageParameters;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.model.PropertyModel;

/**
 * Homepage
 */
public class HomePage extends WebPage
{

	private static final long serialVersionUID = 1L;

	private String text;
	private String anotherText;

	/**
	 * Constructor that is invoked when page is invoked without a session.
	 * 
	 * @param parameters
	 *            Page parameters
	 */
	public HomePage(final PageParameters parameters)
	{


		Form form = new Form("form");
		add(form);
		form.add(new RichEditor("editor", new PropertyModel<String>(this, "text")));

		Form anotherForm = new Form("anotherForm");
		add(anotherForm);
		anotherForm.add(new RichEditor("anotherEditor", new PropertyModel<String>(this,
				"anotherText")));

	}
}
